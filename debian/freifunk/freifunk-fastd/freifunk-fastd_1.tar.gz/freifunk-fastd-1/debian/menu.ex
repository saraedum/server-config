?package(freifunk-fastd):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="freifunk-fastd" command="/usr/bin/freifunk-fastd"
