# Defaults for freifunk-fastd initscript
# sourced by /etc/init.d/freifunk-fastd
# installed at /etc/default/freifunk-fastd by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
