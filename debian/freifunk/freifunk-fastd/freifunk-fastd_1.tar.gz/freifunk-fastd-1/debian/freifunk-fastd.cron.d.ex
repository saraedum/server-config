#
# Regular cron jobs for the freifunk-fastd package
#
0 4	* * *	root	[ -x /usr/bin/freifunk-fastd_maintenance ] && /usr/bin/freifunk-fastd_maintenance
