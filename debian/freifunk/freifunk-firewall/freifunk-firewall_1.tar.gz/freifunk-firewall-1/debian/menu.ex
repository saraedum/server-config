?package(freifunk-firewall):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="freifunk-firewall" command="/usr/bin/freifunk-firewall"
