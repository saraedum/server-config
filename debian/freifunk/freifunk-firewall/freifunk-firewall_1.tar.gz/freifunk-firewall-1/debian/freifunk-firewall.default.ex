# Defaults for freifunk-firewall initscript
# sourced by /etc/init.d/freifunk-firewall
# installed at /etc/default/freifunk-firewall by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
