#
# Regular cron jobs for the freifunk-firewall package
#
0 4	* * *	root	[ -x /usr/bin/freifunk-firewall_maintenance ] && /usr/bin/freifunk-firewall_maintenance
